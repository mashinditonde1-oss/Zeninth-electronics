// Sample reviews data
const reviews = [
    {
        id: 1,
        name: 'Tendai M.',
        rating: 5,
        comment: 'Excellent service and fast delivery. My new laptop works perfectly!',
        date: '2025-10-15',
        product: 'UltraBook Pro 15"'
    },
    {
        id: 2,
        name: 'Ruvimbo C.',
        rating: 4,
        comment: 'Great products at competitive prices. Will definitely shop again.',
        date: '2025-10-10',
        product: 'Smartphone X1 Pro'
    },
    {
        id: 3,
        name: 'Tatenda K.',
        rating: 5,
        comment: 'The solar system installation was professional and the team was very helpful.',
        date: '2025-10-05',
        product: 'Home Solar Kit 5KW'
    }
];

// Function to render reviews
function renderReviews() {
    const reviewsContainer = document.getElementById('reviews-container');
    if (!reviewsContainer) return;

    const reviewsHTML = reviews.map(review => `
        <div class="review-card">
            <div class="review-header">
                <div class="reviewer">
                    <div class="reviewer-avatar">${review.name.charAt(0)}</div>
                    <div class="reviewer-info">
                        <h4>${review.name}</h4>
                        <div class="review-rating">
                            ${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}
                            <span class="review-product">${review.product}</span>
                        </div>
                    </div>
                </div>
                <span class="review-date">${new Date(review.date).toLocaleDateString()}</span>
            </div>
            <p class="review-comment">${review.comment}</p>
        </div>
    `).join('');

    reviewsContainer.innerHTML = reviewsHTML;
}

// Function to handle review submission
function handleReviewSubmit(e) {
    e.preventDefault();
    
    const name = document.getElementById('review-name').value.trim();
    const rating = document.querySelector('input[name="rating"]:checked');
    const comment = document.getElementById('review-comment').value.trim();
    const product = document.getElementById('review-product').value;
    
    if (!name || !rating || !comment) {
        alert('Please fill in all fields and select a rating');
        return;
    }
    
    const newReview = {
        id: Date.now(),
        name,
        rating: parseInt(rating.value),
        comment,
        product,
        date: new Date().toISOString().split('T')[0]
    };
    
    // In a real app, you would send this to your server
    reviews.unshift(newReview);
    
    // Reset form
    e.target.reset();
    
    // Re-render reviews
    renderReviews();
    
    // Show success message
    const successMsg = document.createElement('div');
    successMsg.className = 'alert success';
    successMsg.textContent = 'Thank you for your review!';
    const form = document.getElementById('review-form');
    form.parentNode.insertBefore(successMsg, form.nextSibling);
    
    // Remove success message after 3 seconds
    setTimeout(() => {
        successMsg.remove();
    }, 3000);
}

// Initialize reviews when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    renderReviews();
    
    const reviewForm = document.getElementById('review-form');
    if (reviewForm) {
        reviewForm.addEventListener('submit', handleReviewSubmit);
    }
    
    // Initialize star rating
    const stars = document.querySelectorAll('.star-rating .star');
    stars.forEach((star, index) => {
        star.addEventListener('click', () => {
            const value = index + 1;
            document.querySelector('input[name="rating"]:checked')?.removeAttribute('checked');
            document.getElementById(`rating-${value}`).checked = true;
            
            // Update visual rating
            stars.forEach((s, i) => {
                s.classList.toggle('active', i <= index);
            });
        });
    });
});
