// Cart functionality
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Initialize the checkout page
function initCheckout() {
    updateCartDisplay();
    setupEventListeners();
}

// Update the cart display
function updateCartDisplay() {
    const cartItemsContainer = document.getElementById('cart-items');
    const cartTotalElement = document.getElementById('cart-total');
    
    if (!cartItemsContainer) return;
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p>Your cart is empty</p>';
        cartTotalElement.textContent = '$0.00';
        return;
    }
    
    let total = 0;
    let itemsHTML = '';
    
    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        itemsHTML += `
            <div class="cart-item" data-id="${item.id}">
                <div class="item-details">
                    <h4>${item.name}</h4>
                    <div class="item-meta">
                        <span class="item-quantity">Qty: ${item.quantity}</span>
                    </div>
                </div>
                <div class="item-price">$${itemTotal.toFixed(2)}</div>
            </div>
        `;
    });
    
    cartItemsContainer.innerHTML = itemsHTML;
    cartTotalElement.textContent = `$${total.toFixed(2)}`;
}

// Setup event listeners
function setupEventListeners() {
    // WhatsApp checkout button
    const whatsappCheckoutBtn = document.getElementById('whatsapp-checkout');
    if (whatsappCheckoutBtn) {
        whatsappCheckoutBtn.addEventListener('click', processOrder);
    }
}

// Process the order via WhatsApp
function processOrder() {
    const form = document.getElementById('checkout-form');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    const fullName = document.getElementById('full-name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const address = document.getElementById('address').value.trim();
    const notes = document.getElementById('notes').value.trim();
    
    // Format order details
    let orderDetails = `*NEW ORDER*%0A%0A`;
    orderDetails += `*Customer:* ${fullName}%0A`;
    orderDetails += `*Phone:* ${phone}%0A`;
    orderDetails += `*Delivery Address:* ${address}%0A%0A`;
    
    // Add items to order details
    orderDetails += `*Order Items:*%0A`;
    let orderTotal = 0;
    
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        orderTotal += itemTotal;
        orderDetails += `- ${item.name} x${item.quantity}  ($${itemTotal.toFixed(2)})%0A`;
    });
    
    // Add order notes if any
    if (notes) {
        orderDetails += `%0A*Order Notes:* ${notes}%0A`;
    }
    
    // Add total
    orderDetails += `%0A*Total: $${orderTotal.toFixed(2)}*`;
    
    // Create WhatsApp message
    const phoneNumber = '263773029654'; // Your WhatsApp number
    const message = `Hi Zeninth Electronics, I would like to place an order:%0A%0A${orderDetails}`;
    
    // Open WhatsApp with the order
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
    
    // Clear the cart after order
    cart = [];
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Redirect to thank you page or show success message
    alert('Thank you for your order! Please complete your purchase on WhatsApp.');
    window.location.href = 'index.html';
}

// Load cart from localStorage when the page loads
document.addEventListener('DOMContentLoaded', () => {
    // Only initialize if we're on the checkout page
    if (document.querySelector('.checkout-section')) {
        initCheckout();
    }
});
